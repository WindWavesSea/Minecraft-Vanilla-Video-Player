function animations:load/scoreboards
function animations:load/storages