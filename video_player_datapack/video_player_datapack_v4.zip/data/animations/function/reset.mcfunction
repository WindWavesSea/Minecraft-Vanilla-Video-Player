function animations:reset/scoreboards
function animations:reset/storages